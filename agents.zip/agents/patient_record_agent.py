def save_record(text, analysis):
    return {
        "prescription_text": text,
        "analysis": analysis
    }
